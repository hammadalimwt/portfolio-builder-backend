/* ── LOADER ── */
window.addEventListener('load', () => {
  setTimeout(() => {
    const loader = document.getElementById('loader');
    if (loader) loader.classList.add('hide');
  }, 2400);
});

/* ── NAV SCROLL ── */
const nav = document.getElementById('nav');
if (nav) {
  window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 50), { passive: true });
}

/* ── HAMBURGER ── */
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');
const mobileClose = document.getElementById('mobileClose');

if (hamburger && mobileMenu) {
  hamburger.addEventListener('click', () => mobileMenu.classList.add('open'));
}
if (mobileClose && mobileMenu) {
  mobileClose.addEventListener('click', () => mobileMenu.classList.remove('open'));
}
function closeMobile() {
  if (mobileMenu) mobileMenu.classList.remove('open');
}

/* ── SCROLL REVEAL ── */
const revealEls = document.querySelectorAll('.reveal');
const ro = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('visible');
      ro.unobserve(e.target);
    }
  });
}, { threshold: 0.1 });
revealEls.forEach(el => ro.observe(el));

/* ── HERO PARTICLES ── */
(function() {
  const canvas = document.getElementById('particles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, pts = [];
  function resize() {
    W = canvas.width = canvas.parentElement.offsetWidth;
    H = canvas.height = canvas.parentElement.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);
  for (let i = 0; i < 70; i++) {
    pts.push({
      x: Math.random() * W,
      y: Math.random() * H,
      vx: (Math.random() - .5) * .35,
      vy: (Math.random() - .5) * .35,
      r: Math.random() * 1.2 + .3,
      o: Math.random() * .4 + .1
    });
  }
  let mx = W/2, my = H/2;
  window.addEventListener('mousemove', e => { mx = e.clientX; my = e.clientY; }, { passive: true });
  function draw() {
    ctx.clearRect(0, 0, W, H);
    pts.forEach((p, i) => {
      p.x += p.vx; p.y += p.vy;
      if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
      if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
      ctx.fillStyle = `rgba(100,132,255,${p.o})`; ctx.fill();
      pts.slice(i+1).forEach(q => {
        const d = Math.hypot(p.x-q.x, p.y-q.y);
        if (d < 90) {
          ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y);
          ctx.strokeStyle = `rgba(65,105,255,${.1 * (1 - d / 90)})`; ctx.lineWidth = .6; ctx.stroke();
        }
      });
    });
    requestAnimationFrame(draw);
  }
  draw();
})();

/* ── FULL BG CANVAS — flowing dots ── */
(function() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, stars = [];
  function resize() {
    W = canvas.width = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);
  for (let i = 0; i < 120; i++) {
    stars.push({
      x: Math.random() * W,
      y: Math.random() * H,
      r: Math.random() * 0.8 + 0.1,
      o: Math.random() * 0.15 + 0.02,
      vx: (Math.random() - .5) * 0.15,
      vy: (Math.random() - .5) * 0.15
    });
  }
  function drawBg() {
    ctx.clearRect(0, 0, W, H);
    stars.forEach(s => {
      s.x += s.vx; s.y += s.vy;
      if (s.x < 0) s.x = W; if (s.x > W) s.x = 0;
      if (s.y < 0) s.y = H; if (s.y > H) s.y = 0;
      ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, Math.PI*2);
      ctx.fillStyle = `rgba(150,180,255,${s.o})`; ctx.fill();
    });
    requestAnimationFrame(drawBg);
  }
  drawBg();
})();

/* ── MOUSE PARALLAX ON PHOTO ── */
(function() {
  const scene = document.getElementById('photoScene');
  if (!scene) return;
  let tiltX = 0, tiltY = 0, targetX = 0, targetY = 0;
  window.addEventListener('mousemove', e => {
    const cx = window.innerWidth / 2, cy = window.innerHeight / 2;
    targetX = (e.clientY - cy) / cy * -8;
    targetY = (e.clientX - cx) / cx * 8;
  }, { passive: true });
  function animate() {
    tiltX += (targetX - tiltX) * 0.07;
    tiltY += (targetY - tiltY) * 0.07;
    scene.style.transform = `perspective(800px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`;
    requestAnimationFrame(animate);
  }
  animate();

  const photo = document.getElementById('heroPhoto');
  window.addEventListener('scroll', () => {
    const scrolled = window.scrollY;
    if (scrolled < window.innerHeight && photo) {
      photo.style.transform = `translateY(${scrolled * 0.18}px)`;
    }
  }, { passive: true });
})();

/* ── FORM SUBMIT ── */
function handleSubmit(btn) {
  const orig = btn.textContent;
  btn.textContent = 'Sending...'; btn.disabled = true;
  setTimeout(() => {
    btn.textContent = '✓ Message Sent!'; btn.style.background = '#10b981';
    setTimeout(() => { btn.textContent = orig; btn.style.background = ''; btn.disabled = false; }, 3000);
  }, 1500);
}

/* ── ACTIVE NAV ── */
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.nav-links a');
window.addEventListener('scroll', () => {
  let cur = '';
  sections.forEach(s => { if (window.scrollY >= s.offsetTop - 200) cur = s.id; });
  navLinks.forEach(a => { a.style.color = a.getAttribute('href') === '#' + cur ? 'var(--text)' : ''; });
}, { passive: true });

/* ── DYNAMIC PARAMETERS PARSING ── */
document.addEventListener('DOMContentLoaded', () => {
  // 1. Name Splitting
  const nameEl = document.getElementById('heroName');
  if (nameEl) {
    const fullName = nameEl.textContent.trim();
    const parts = fullName.split(' ');
    if (parts.length > 1) {
      const first = parts.slice(0, -1).join(' ');
      const last = parts[parts.length - 1];
      nameEl.innerHTML = `<span class="first">${first}</span><span class="last neon-text">${last}</span>`;
    } else {
      nameEl.innerHTML = `<span class="first">${fullName}</span><span class="last neon-text"></span>`;
    }
  }

  // 2. Skills Extraction and Lists
  const skillsList = [];
  document.querySelectorAll('.about-tag').forEach(tag => {
    skillsList.push(tag.textContent.trim());
  });

  // 3. Dynamic Skills Bars
  const barsContainer = document.getElementById('skills-bars-container');
  if (barsContainer && skillsList.length > 0) {
    barsContainer.innerHTML = '';
    const displaySkills = skillsList.slice(0, 6);
    const defaultPcts = [92, 88, 85, 83, 80, 78];
    displaySkills.forEach((skill, index) => {
      const pct = defaultPcts[index] || 75;
      const barItem = document.createElement('div');
      barItem.className = 'bar-item';
      barItem.innerHTML = `
        <div class="bar-head">
          <span class="bar-name">${skill}</span>
          <span class="bar-pct">${pct}%</span>
        </div>
        <div class="bar-track">
          <div class="bar-fill" data-w="${pct}"></div>
        </div>
      `;
      barsContainer.appendChild(barItem);
    });
    // Set up skills bar trigger
    const skillObs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.bar-fill').forEach(b => b.style.width = b.dataset.w + '%');
          skillObs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    skillObs.observe(barsContainer);
  }

  // 4. Dynamic Skills Orbs
  const orbsContainer = document.getElementById('skills-orbs-container');
  if (orbsContainer && skillsList.length > 0) {
    orbsContainer.innerHTML = '';
    const iconMap = {
      'react': 'fa-brands fa-react',
      'reactjs': 'fa-brands fa-react',
      'node': 'fa-brands fa-node-js',
      'node.js': 'fa-brands fa-node-js',
      'nodejs': 'fa-brands fa-node-js',
      'express': 'fa-solid fa-server',
      'expressjs': 'fa-solid fa-server',
      'mongodb': 'fa-solid fa-database',
      'mongo': 'fa-solid fa-database',
      'javascript': 'fa-brands fa-js',
      'js': 'fa-brands fa-js',
      'html': 'fa-brands fa-html5',
      'css': 'fa-brands fa-css3-alt',
      'git': 'fa-brands fa-git-alt',
      'github': 'fa-brands fa-github'
    };
    
    skillsList.slice(0, 9).forEach(skill => {
      const cleanSkill = skill.toLowerCase().replace(/\s+/g, '');
      const iconClass = iconMap[cleanSkill] || 'fa-solid fa-code';
      const orb = document.createElement('div');
      orb.className = 'sorb';
      orb.innerHTML = `
        <div class="sorb-icon"><i class="${iconClass}"></i></div>
        <div class="sorb-name">${skill}</div>
      `;
      orbsContainer.appendChild(orb);
    });
  }

  // 5. Dynamic Floating Tags based on Skills
  const floatTag1 = document.querySelector('.float-tag-1');
  const floatTag2 = document.querySelector('.float-tag-2');
  if (skillsList.length > 0 && floatTag2) {
    floatTag2.innerHTML = `${skillsList[0]}<span class="tag-val">Developer</span>`;
  }
  if (skillsList.length > 1 && floatTag1) {
    floatTag1.innerHTML = `${skillsList[1]}<span class="tag-val">Expert</span>`;
  }

  // 6. Limit Projects to max 10 items
  const projGrid = document.querySelector('.projects-grid');
  if (projGrid) {
    const cards = Array.from(projGrid.querySelectorAll('.proj-card'));
    if (cards.length > 10) {
      cards.slice(10).forEach(card => card.remove());
    }
  }
});
