const init = () => {
  // Preloader
  const preloader = document.getElementById('preloader');
  if (preloader) {
    setTimeout(() => {
      preloader.classList.add('fade-out');
      setTimeout(() => {
        preloader.style.display = 'none';
      }, 800);
    }, 1200);
  }

  // Scroll Reveal
  const revealElements = document.querySelectorAll('.reveal');
  const revealOnScroll = () => {
    for (let i = 0; i < revealElements.length; i++) {
      const windowHeight = window.innerHeight;
      const elementTop = revealElements[i].getBoundingClientRect().top;
      const elementVisible = 150;
      if (elementTop < windowHeight - elementVisible) {
        revealElements[i].classList.add('revealed');
      }
    }
  };
  window.addEventListener('scroll', revealOnScroll);
  // Trigger once at load
  setTimeout(revealOnScroll, 1500);

  // Fullscreen Menu Drawer Toggle
  const menuToggle = document.getElementById('menuToggle');
  const menuDrawer = document.getElementById('menuDrawer');
  const drawerLinks = document.querySelectorAll('.menu-drawer-links a');

  if (menuToggle && menuDrawer) {
    menuToggle.addEventListener('click', () => {
      menuToggle.classList.toggle('active');
      menuDrawer.classList.toggle('active');
      
      if (menuDrawer.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
      } else {
        document.body.style.overflow = '';
      }
    });

    drawerLinks.forEach(link => {
      link.addEventListener('click', () => {
        menuToggle.classList.remove('active');
        menuDrawer.classList.remove('active');
        document.body.style.overflow = '';
      });
    });
  }

  // Smooth Scroll
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        targetElement.scrollIntoView({
          behavior: 'smooth'
        });
      }
    });
  });

  // Project Modal
  const workItems = document.querySelectorAll('.work-item');
  const projectModal = document.getElementById('projectModal');
  const modalImage = document.getElementById('modalImage');
  const modalTech = document.getElementById('modalTech');
  const modalTitle = document.getElementById('modalTitle');
  const modalDesc = document.getElementById('modalDesc');
  const modalGithub = document.getElementById('modalGithub');
  const modalLive = document.getElementById('modalLive');
  const modalClose = document.getElementById('modalClose');
  const modalOverlay = document.getElementById('modalOverlay');

  if (workItems.length > 0 && projectModal) {
    workItems.forEach(item => {
      item.addEventListener('click', () => {
        const name = item.getAttribute('data-name') || '';
        const tech = item.getAttribute('data-tech') || '';
        const desc = item.getAttribute('data-desc') || '';
        const img = item.getAttribute('data-img') || '';
        const github = item.getAttribute('data-github') || '';
        const live = item.getAttribute('data-live') || '';

        if (modalImage) modalImage.src = img;
        if (modalTech) modalTech.textContent = tech;
        if (modalTitle) modalTitle.textContent = name;
        if (modalDesc) modalDesc.textContent = desc;

        if (modalGithub) {
          if (github && github !== 'undefined' && github !== 'null') {
            modalGithub.href = github;
            modalGithub.style.display = 'inline-block';
          } else {
            modalGithub.style.display = 'none';
          }
        }

        if (modalLive) {
          if (live && live !== 'undefined' && live !== 'null') {
            modalLive.href = live;
            modalLive.style.display = 'inline-block';
          } else {
            modalLive.style.display = 'none';
          }
        }

        projectModal.classList.add('active');
        document.body.style.overflow = 'hidden';
      });
    });

    const closeModal = () => {
      projectModal.classList.remove('active');
      if (!menuDrawer.classList.contains('active')) {
        document.body.style.overflow = '';
      }
    };

    if (modalClose) modalClose.addEventListener('click', closeModal);
    if (modalOverlay) modalOverlay.addEventListener('click', closeModal);
    
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeModal();
      }
    });
  }
};
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}