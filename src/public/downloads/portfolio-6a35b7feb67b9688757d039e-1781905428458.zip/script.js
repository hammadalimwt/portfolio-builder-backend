/* ==========================================================================
   AETHER TECH PREMIUM — FUTURISTIC DEVELOPER PORTFOLIO JAVASCRIPT
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  
  // Set Current Year
  const yearEl = document.getElementById('current-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // Dynamic Timeline Experience Fallback (if no entries exist)
  const timeline = document.querySelector('.timeline-container');
  if (timeline) {
    const items = timeline.querySelectorAll('.timeline-item');
    if (items.length === 0) {
      const defaultCard = document.createElement('div');
      defaultCard.className = 'timeline-item scroll-reveal visible';
      defaultCard.innerHTML = `
        <div class="timeline-dot"></div>
        <div class="timeline-content-card">
          <div class="card-header">
            <h3 class="role-title">Professional Fullstack Engineer</h3>
            <span class="role-duration">2022 - Present</span>
          </div>
          <div class="company-badge">Freelance Consultant</div>
          <p class="role-desc">
            Designing, developing, and deploying highly optimized fullstack MERN web applications for agencies, startups, and remote teams.
          </p>
        </div>
      `;
      timeline.appendChild(defaultCard);
    }
  }

  // Hide Loader on Page Load
  window.addEventListener('load', () => {
    const loader = document.getElementById('aether-loader');
    if (loader) {
      setTimeout(() => {
        loader.classList.add('hide');
      }, 1000); // 1-second delay for smooth aesthetics
    }
  });
  
  // Fallback loader hide if window load event already fired
  setTimeout(() => {
    const loader = document.getElementById('aether-loader');
    if (loader && !loader.classList.contains('hide')) {
      loader.classList.add('hide');
    }
  }, 3000);

  // Nav Scroll effect
  const nav = document.getElementById('aether-nav');
  if (nav) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 40) {
        nav.classList.add('scrolled');
      } else {
        nav.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  // Hamburger Menu Toggle
  const hamburger = document.getElementById('hamburger-btn');
  const overlay = document.getElementById('mobile-overlay');
  
  if (hamburger && overlay) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active');
      overlay.classList.toggle('open');
      document.body.style.overflow = overlay.classList.contains('open') ? 'hidden' : '';
    });

    // Close menu when clicking link
    overlay.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        overlay.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }

  // Scroll Reveal Animations
  const revealElements = document.querySelectorAll('.scroll-reveal');
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        revealObserver.unobserve(entry.target); // Reveal once
      }
    });
  }, {
    threshold: 0.05,
    rootMargin: '0px 0px -50px 0px'
  });

  revealElements.forEach(el => revealObserver.observe(el));

  // Flowing Background Particles with Mouse Interactivity
  const initParticles = () => {
    const canvas = document.getElementById('aether-particles');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let W, H;
    let particles = [];
    const particleCount = 60;
    
    const mouse = {
      x: null,
      y: null,
      radius: 120
    };

    const resize = () => {
      W = canvas.width = window.innerWidth;
      H = canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize, { passive: true });

    window.addEventListener('mousemove', (e) => {
      mouse.x = e.clientX;
      mouse.y = e.clientY;
    }, { passive: true });

    window.addEventListener('mouseleave', () => {
      mouse.x = null;
      mouse.y = null;
    }, { passive: true });

    class Particle {
      constructor() {
        this.x = Math.random() * W;
        this.y = Math.random() * H;
        this.size = Math.random() * 1.5 + 0.5;
        this.baseX = this.x;
        this.baseY = this.y;
        this.vx = (Math.random() - 0.5) * 0.2;
        this.vy = (Math.random() - 0.5) * 0.2;
        this.opacity = Math.random() * 0.4 + 0.1;
      }

      update() {
        // Move particle slowly
        this.x += this.vx;
        this.y += this.vy;

        // Wrap around boundaries
        if (this.x < 0) this.x = W;
        if (this.x > W) this.x = 0;
        if (this.y < 0) this.y = H;
        if (this.y > H) this.y = 0;

        // Mouse repelling interaction
        if (mouse.x !== null && mouse.y !== null) {
          const dx = this.x - mouse.x;
          const dy = this.y - mouse.y;
          const distance = Math.hypot(dx, dy);
          
          if (distance < mouse.radius) {
            const force = (mouse.radius - distance) / mouse.radius;
            const forceX = (dx / distance) * force * 1.2;
            const forceY = (dy / distance) * force * 1.2;
            this.x += forceX;
            this.y += forceY;
          }
        }
      }

      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(129, 140, 248, ${this.opacity})`;
        ctx.fill();
      }
    }

    // Spawn Particles
    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle());
    }

    const animate = () => {
      ctx.clearRect(0, 0, W, H);
      particles.forEach(p => {
        p.update();
        p.draw();
      });
      requestAnimationFrame(animate);
    };
    animate();
  };
  initParticles();

  // 3D Profile Cube Rotation Tilt Effect
  const initProfileTilt = () => {
    const cube = document.getElementById('photo-cube');
    if (!cube) return;

    let targetRotateX = 0;
    let targetRotateY = 0;
    let currentRotateX = 0;
    let currentRotateY = 0;

    window.addEventListener('mousemove', (e) => {
      const W = window.innerWidth;
      const H = window.innerHeight;
      const mouseX = e.clientX - W / 2;
      const mouseY = e.clientY - H / 2;

      // Max tilt angle is 10 degrees
      targetRotateY = (mouseX / (W / 2)) * 10;
      targetRotateX = (mouseY / (H / 2)) * -10;
    }, { passive: true });

    const smoothAnimate = () => {
      currentRotateX += (targetRotateX - currentRotateX) * 0.08;
      currentRotateY += (targetRotateY - currentRotateY) * 0.08;
      
      cube.style.transform = `perspective(1000px) rotateX(${currentRotateX}deg) rotateY(${currentRotateY}deg)`;
      requestAnimationFrame(smoothAnimate);
    };
    smoothAnimate();
  };
  initProfileTilt();

  // Dynamic Skill Card Renderer
  const initSkills = () => {
    const wrapper = document.getElementById('skills-grid-wrapper');
    if (!wrapper) return;

    // Gather unique skill tags from biography list
    const tags = Array.from(document.querySelectorAll('.aether-tag')).map(el => el.textContent.trim());
    if (tags.length === 0) return;

    wrapper.innerHTML = '';
    
    // Distribute random percentage levels to create a authentic visual dashboard
    const defaultPcts = [94, 90, 88, 85, 82, 80, 78, 75, 72, 70];
    
    tags.forEach((skill, index) => {
      const pct = defaultPcts[index % defaultPcts.length];
      const card = document.createElement('div');
      card.className = 'skill-bar-card scroll-reveal';
      card.style.transitionDelay = `${(index % 3) * 0.1}s`;
      
      card.innerHTML = `
        <div class="skill-bar-head">
          <span class="skill-bar-name">${skill}</span>
          <span class="skill-bar-pct">${pct}%</span>
        </div>
        <div class="skill-bar-track">
          <div class="skill-bar-fill" data-w="${pct}"></div>
        </div>
      `;
      wrapper.appendChild(card);
      revealObserver.observe(card); // Hook up reveal observer
    });

    // Animate skill bars when visible
    const skillObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.querySelectorAll('.skill-bar-fill').forEach(fill => {
            fill.style.width = fill.dataset.w + '%';
          });
          skillObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });
    skillObserver.observe(wrapper);
  };
  initSkills();

});

// Contact Form submission mockup helper
function submitAetherForm(form) {
  const submitBtn = form.querySelector('.form-submit-btn');
  if (!submitBtn) return;

  const originalContent = submitBtn.innerHTML;
  submitBtn.disabled = true;
  submitBtn.innerHTML = `<span>Sending...</span> <i class="fa-solid fa-circle-notch fa-spin"></i>`;

  setTimeout(() => {
    submitBtn.innerHTML = `<span>✓ Sent Successfully!</span>`;
    submitBtn.style.background = 'var(--success)';
    submitBtn.style.boxShadow = '0 4px 15px rgba(16, 185, 129, 0.3)';
    
    setTimeout(() => {
      form.reset();
      submitBtn.innerHTML = originalContent;
      submitBtn.style.background = '';
      submitBtn.style.boxShadow = '';
      submitBtn.disabled = false;
    }, 3000);
  }, 1800);
}
